﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DocumentMerger2
{
    class Program
    {
        static void Main(string[] args)
        {
            string TextFile1 = args[0];
            string TextFile2 = args[1];
            string FinalDoc = args[2];

            if (args.Length >= 3)
            {
                Console.WriteLine("DocumentMerger2 <input_file_1> <input_file_2> ... <input_file_n> <output_file>");
                Console.WriteLine("Supply a list of text files to merge followed by the name of the resulting merged text file as command line arguments.");
            }
            else
            {
                Console.WriteLine("no arguments were provided");
            }
            Console.WriteLine("Document Merger");

        
            
            {

                Console.WriteLine(File.Exists(TextFile1) ? "File exists." : "File does not exist.");
                if (!File.Exists(TextFile1))
                {
                    Console.WriteLine("File does not exist");
                }
                
                Console.WriteLine(File.Exists(TextFile2) ? "File exists" : "File does not exist");
                if (!File.Exists(TextFile2))
                {
                    Console.WriteLine("file does not exist");
                }
                
            } 
            StreamWriter sw = new StreamWriter(TextFile1 + ".txt");
            StreamWriter sw2 = new StreamWriter(TextFile2 + ".txt");
            try
            {
                StreamReader sr = new StreamReader(TextFile1);

                string line = null;
                while ((line = sr.ReadLine()) != null)
                {
                    sw.WriteLine(line);
                }

                StreamReader sr2 = new StreamReader(TextFile2);
                string line2 = null;
                while((line2 =sr2.ReadLine())!= null)
                {
                    sw.WriteLine(line2);
                }

                FinalDoc = String.Format("{0}{1}.txt", TextFile1, TextFile2);

                while (FinalDoc != null)
                {
                    Console.WriteLine(FinalDoc);
                    FinalDoc = sr.ReadLine();
                }
                sr.Close();
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception:" + e.Message);
            }
            finally
            {
                if (File.Exists(FinalDoc))
                {
                    Console.WriteLine("{0} was successfuly saved. The document contains {1} characters", FinalDoc, FinalDoc.Length);
                }
                else
                {
                    Console.WriteLine("Please exit program and try again");
                }
            }
            Console.ReadKey();

        }
    }
}
            
    

